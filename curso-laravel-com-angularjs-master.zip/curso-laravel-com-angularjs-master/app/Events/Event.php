<?php

namespace CodeProject\Events;

abstract class Event
{
    //
}
